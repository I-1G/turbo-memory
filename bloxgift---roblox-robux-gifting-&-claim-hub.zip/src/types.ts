export interface RobloxUser {
  username: string;
  displayName: string;
  id: number;
  avatar: string;
  avatarHeadshot?: string;
  avatarFull?: string;
  isVerified?: boolean;
  joinDate?: string;
  friendsCount?: number;
  followingCount?: number;
  followersCount?: number;
  rolimonsUrl?: string;
  rolimonsValue?: number;
  rolimonsRap?: number;
  rolimonsRank?: number;
}

export interface LedgerItem {
  id: string | number;
  sender: string;
  recipient: string;
  amount: number;
  note: string;
  status: 'CLAIMED';
  isWZ?: boolean;
  time: string;
  avatar: string;
  rolimonsUrl?: string;
}

export interface LeaderboardUser {
  rank: number;
  username: string;
  displayName: string;
  amountGifted: number;
  avatar: string;
  avatarFull?: string;
  badge: string;
  borderColor: string;
  accentBg: string;
  rolimonsUrl?: string;
}

export interface ToastItem {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'info' | 'error';
}
