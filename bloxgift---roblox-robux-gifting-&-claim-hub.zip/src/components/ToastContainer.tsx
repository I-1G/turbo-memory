import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { ToastItem } from '../types';

interface ToastContainerProps {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 pointer-events-none max-w-sm w-full px-4">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto bg-[#14161c] border rounded-2xl p-4 shadow-2xl flex items-start gap-3 transition-all duration-300 animate-in slide-in-from-bottom-2 ${
              isSuccess
                ? 'border-[#00e676]/40 text-white'
                : isError
                ? 'border-[#ee4835]/40 text-white'
                : 'border-[#00a2ff]/40 text-white'
            }`}
          >
            <div className="mt-0.5 shrink-0">
              {isSuccess ? (
                <CheckCircle2 className="w-5 h-5 text-[#00e676]" />
              ) : isError ? (
                <AlertCircle className="w-5 h-5 text-[#ee4835]" />
              ) : (
                <Info className="w-5 h-5 text-[#00a2ff]" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold leading-tight truncate">
                {toast.title}
              </h4>
              {toast.message && (
                <p className="text-[11px] text-gray-300 mt-0.5 leading-snug">
                  {toast.message}
                </p>
              )}
            </div>

            <button
              onClick={() => onDismiss(toast.id)}
              className="text-gray-400 hover:text-white transition-colors p-1"
              aria-label="Dismiss toast"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
